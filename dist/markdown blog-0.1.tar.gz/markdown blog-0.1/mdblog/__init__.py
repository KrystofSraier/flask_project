from celery import Celery

celery = Celery("mdblog.factory")